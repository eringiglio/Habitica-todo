""" Habitica-todo 

	Python scripts that should convert and sync tasks between Habitica and Todoist.
"""

from .main import *

import oneWaySync